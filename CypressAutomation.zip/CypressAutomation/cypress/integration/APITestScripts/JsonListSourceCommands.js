import JsonPage from "../../support/PageObjects/JsonPage";

describe("Verification of JSONAPIs", function () {

    let jsonIP = "10.98.6.65:9999"
    let jsonCmd = '{"params":{"type": 0}, "method":"listSources", "id":"1234", "jsonrpc":"2.0"}'
    let jsonRsp = '{"id":15,"Name":"ButtonLayout-16","HSize":471,"VSize":368,"SrcType":1,"InputCfgIndex":-1,"StillIndex":6,"DestIndex":-1,"UserKeyIndex":-1,"Freeze":0,"Capacity":1}'


    it(" Verification of ListSource API from BackEnd to FrontEnd", function () {

        cy.log(jsonIP)
        cy.log(jsonCmd)
        cy.request({
            method: 'POST',
            url: jsonIP,
            body: jsonCmd
        }).then((response) => {
            expect(response).property('status').to.equal(200)
            expect(response.body, 'response body').to.deep.equal({
                jsonRsp
            })
        })


        /*
        const jsonPage = new JsonPage()
        cy.visit(Cypress.env('url'))
        jsonPage.JsonTab().click()
        jsonPage.IPInput().click()
        jsonPage.IPInput().type(jsonIP)
        jsonPage.CmdInput().click()
        jsonPage.CmdInput().type(jsonCmdListSource)
        jsonPage.Send().click()
        jsonPage.ResponseData().then(function (rp) {
            var responsedata = rp.text()
            cy.log(responsedata)
        })*/


    })
})