import DashBoardPage from "../../support/PageObjects/DashBoardPage";

describe("Verification of WebApp Dashboard Page", function () {

    before(function () {
        cy.fixture('Common').then(function (commonData) {
            this.commonData = commonData
        })

    })

    it(" Open WebApp and vrify all output cards information under Dashboard section", function () {
        const dashBoardPage = new DashBoardPage()

        cy.visit(Cypress.env('url'))
        dashBoardPage.outPutTab().click()

        //For data rows
        cy.get("#outputs-table tr:visible").should("have.length", 5)

        //For Headers
        dashBoardPage.HeaderList().each(function ($el, index, $list) {
            cy.get($el).should('have.text', this.commonData.expHeaderList[index])
        })

        //For SlotIDs
        dashBoardPage.SlotIDList().each(function ($el, index, $list) {
            cy.get($el).should('have.text', this.commonData.expSlotIDList[index])
        })

        //For CardType
        dashBoardPage.CardTypeList().each(function ($el, index, $list) {
            cy.get($el).should('have.text', this.commonData.expCardTypeList[index])
        })

        //For Card Status
        dashBoardPage.CardStatusList().each(function ($el, index, $list) {
            cy.get($el).should('have.text', this.commonData.expCardStatusList[index])
        })

        //For Card Actions
        dashBoardPage.CardActionsList().each(function ($el, index, $list) {
            cy.get($el).should("contain.text", this.commonData.expCardActionsList[index])
        })
    })
})