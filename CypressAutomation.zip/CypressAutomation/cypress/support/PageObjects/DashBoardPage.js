class DashBoardPage {

    outPutTab() {
        return cy.get("a[href='#outputs']")
    }

    HeaderList() {
        return cy.get("table#outputs-table tr th strong")
    }

    SlotIDList() {
        return cy.get("table#outputs-table tbody tr [class='x-slot-id']")
    }

    CardTypeList() {
        return cy.get("table#outputs-table tbody tr [class='x-slot-card-type']")
    }

    CardStatusList() {
        return cy.get("table#outputs-table tbody tr [class*='x-slot-card-status']")
    }

    CardActionsList() {
        return cy.get("table#outputs-table tbody tr td a")
    }

    JsonPage()
    {
        return cy.get("a[href*='json']")
    }



}

export default DashBoardPage;

