class JsonPage {

    JsonTab() {
        return cy.get("a[href*='json']")
    }

    IPInput() {
        return cy.get("#ipInputText")
    }

    CmdInput() {
        return cy.get("#jsoncmdInputText")
    }

    ResponseData() {
        return cy.get("#responseData")
    }

    SuccessData() {
        return cy.get("#successData")
    }

    ErrorData() {
        return cy.get("#errorData")
    }

    Send() {
        return cy.get("#sendButton")
    }
}

export default JsonPage;

